import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_colors.dart';

class DevCritiqueBottomBar extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTabSelected;

  const DevCritiqueBottomBar({
    super.key,
    required this.currentIndex,
    required this.onTabSelected,
  });

  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    final tabs = [
      {'label': 'CRITIQUES', 'icon': Icons.article_outlined, 'activeIcon': Icons.article_rounded},
      {'label': 'BENCHMARKS', 'icon': Icons.insights_outlined, 'activeIcon': Icons.insights_rounded},
      {'label': 'AI VERDICTS', 'icon': Icons.auto_awesome_outlined, 'activeIcon': Icons.auto_awesome_rounded},
      {'label': 'SAVED', 'icon': Icons.bookmark_border_rounded, 'activeIcon': Icons.bookmark_rounded},
    ];

    return Container(
      height: 64 + bottomPadding,
      padding: EdgeInsets.only(bottom: bottomPadding),
      decoration: const BoxDecoration(
        color: Color(0xF2090D16), // 95% opacity frosted
        border: Border(
          top: BorderSide(color: AppColors.borderHairline, width: 1),
        ),
      ),
      child: Row(
        children: List.generate(tabs.length, (index) {
          final isSelected = currentIndex == index;
          final tab = tabs[index];

          return Expanded(
            child: InkWell(
              onTap: () => onTabSelected(index),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // Top 2px active indicator bar
                  if (isSelected)
                    Positioned(
                      top: 0,
                      left: 16,
                      right: 16,
                      child: Container(
                        height: 2,
                        decoration: BoxDecoration(
                          color: AppColors.accentPrimary,
                          borderRadius: BorderRadius.circular(1),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0x666366F1),
                              blurRadius: 4,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                      ),
                    ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        (isSelected ? tab['activeIcon'] : tab['icon']) as IconData,
                        size: 20,
                        color: isSelected ? AppColors.accentPrimary : AppColors.textTertiary,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        tab['label'] as String,
                        style: GoogleFonts.inter(
                          fontSize: 10,
                          fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
                          letterSpacing: 0.4,
                          color: isSelected ? AppColors.textPrimary : AppColors.textTertiary,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        }),
      ),
    );
  }
}
