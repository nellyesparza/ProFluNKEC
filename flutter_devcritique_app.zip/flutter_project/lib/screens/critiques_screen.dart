import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_colors.dart';
import '../models/review_item.dart';
import '../data/mock_data.dart';
import '../widgets/software_review_card.dart';
import 'review_detail_screen.dart';

class CritiquesScreen extends StatefulWidget {
  const CritiquesScreen({super.key});

  @override
  State<CritiquesScreen> createState() => _CritiquesScreenState();
}

class _CritiquesScreenState extends State<CritiquesScreen> {
  String _selectedCategory = 'All Signals';
  String _searchQuery = '';
  final TextEditingController _searchController = TextEditingController();

  List<ReviewItem> get _filteredReviews {
    return mockReviews.where((item) {
      final matchesCategory = _selectedCategory == 'All Signals' || item.category == _selectedCategory;
      final matchesQuery = _searchQuery.isEmpty ||
          item.title.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          item.consensusVerdict.toLowerCase().contains(_searchQuery.toLowerCase());
      return matchesCategory && matchesQuery;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Search & Filter header
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          color: AppColors.canvasBase,
          child: Column(
            children: [
              // Search Input Field (44px height)
              Container(
                height: 44,
                decoration: BoxDecoration(
                  color: AppColors.surfaceElevation1,
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: AppColors.borderDefault, width: 1),
                ),
                child: TextField(
                  controller: _searchController,
                  style: GoogleFonts.inter(fontSize: 13, color: AppColors.textPrimary),
                  onChanged: (val) => setState(() => _searchQuery = val),
                  decoration: InputDecoration(
                    hintText: 'Filter by stack, runtime or author...',
                    hintStyle: GoogleFonts.inter(fontSize: 13, color: AppColors.textTertiary),
                    prefixIcon: const Icon(Icons.search, size: 18, color: AppColors.textTertiary),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              // Category filter pills
              SizedBox(
                height: 32,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: appCategories.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (context, index) {
                    final cat = appCategories[index];
                    final isSelected = cat == _selectedCategory;
                    return InkWell(
                      onTap: () => setState(() => _selectedCategory = cat),
                      borderRadius: BorderRadius.circular(4),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: isSelected ? AppColors.accentPrimary : AppColors.surfaceElevation1,
                          borderRadius: BorderRadius.circular(4),
                          border: Border.all(
                            color: isSelected ? AppColors.accentPrimary : AppColors.borderHairline,
                            width: 1,
                          ),
                        ),
                        child: Text(
                          cat,
                          style: GoogleFonts.inter(
                            fontSize: 12,
                            fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
                            color: isSelected ? Colors.white : AppColors.textSecondary,
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),

        const Divider(color: AppColors.borderHairline, height: 1),

        // List of software review cards
        Expanded(
          child: _filteredReviews.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.filter_list_off_rounded, size: 36, color: AppColors.textTertiary),
                      const SizedBox(height: 12),
                      Text(
                        'No matching critiques found',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textSecondary,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Try broadening your filter criteria.',
                        style: GoogleFonts.inter(fontSize: 12, color: AppColors.textTertiary),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _filteredReviews.length,
                  itemBuilder: (context, index) {
                    final review = _filteredReviews[index];
                    return SoftwareReviewCard(
                      review: review,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ReviewDetailScreen(review: review),
                          ),
                        );
                      },
                    );
                  },
                ),
        ),
      ],
    );
  }
}
